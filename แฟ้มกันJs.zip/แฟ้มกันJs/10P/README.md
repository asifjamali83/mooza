## For install Tutorial [HERE](https://www.youtube.com/watch?v=v_h-t8iGYzQ&t=28s)
# ![logo](LINE-sm.png) LINE Python

*LINE Messaging's private API*

----
# [ADD ME!](http://line.me/ti/p/~adit_cmct)
# Ambil Token Bisa Di
# [ADITMADZS Bot Public](line.me/ti/p/~botaditmadzs)

# Termux

```sh
$ apt update
$ apt upgrade
$ apt install python
$ pip3 install pytz
$ pip3 install requests
$ pip3 install rsa
$ pip3 install bs4
$ pip3 install gtts 
$ pip3 install goslate
$ pip3 install googletrans
$ pip3 install pafy
$ pip3 install youtube_dl
$ pip3 install humanfriendly
$ pip3 install thrift==0.11.0
$ pip3 install tweepy
$ pip3 install wikipedia
$ apt install git
$ git clone https://github.com/Aditmadzs/Aditmadzs2
$ cd Aditmadzs2
$ python3 adit.py
```

# VPS

```sh
$ sudo apt-get update
$ sudo apt-get install python3-pip
$ sudo apt-get install python3-tz
$ sudo pip3 install requests
$ sudo pip3 install rsa 
$ sudo pip3 install bs4 
$ sudo pip3 install gtts 
$ sudo pip3 install goslate
$ sudo pip3 install googletrans 
$ sudo pip3 install pafy 
$ sudo pip3 install youtube_dl 
$ sudo pip3 install humanfriendly
$ sudo pip3 install thrift==0.11.0
$ sudo pip3 install tweepy
$ sudo pip3 install wikipedia
$ sudo apt-get install git
$ git clone https://github.com/Aditmadzs/Aditmadzs2
$ cd Aditmadzs2
$ python3 adit.py
```

